import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-YJHSSB7B.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-TAQPA45R.js";
import "./chunk-QL2QQ4MJ.js";
import "./chunk-5SIMMRLZ.js";
import "./chunk-VNG2453I.js";
import "./chunk-BO6B27D7.js";
import "./chunk-ITRRYPD6.js";
import "./chunk-DZQK7PR5.js";
import "./chunk-IEMOZLTW.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
