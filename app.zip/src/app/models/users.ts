export interface User{
    id: number;
    name: string;
    lastname: string;
    email: string;
    password: string;
    dni: string;
    birthdate: Date;
    date_register: Date;
    phone: string;
    photo: string;
}