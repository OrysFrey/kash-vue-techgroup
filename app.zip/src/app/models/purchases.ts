export interface Purchase{
    id: number;
    id_customer: number;
    id_product: number;
    price: number;
    amount: number;
    date_register: Date;
    interest: number;
    status: string; //Pendiente - Pagado
}